const products = [
    { id: 1, name: "AIRPODS MAX", price: 25, image: "./images/Products/APPLE AIRPODS MAX.jpg" },
    { id: 2, name: "FOSSIL", price: 20, image: "./images/Products/FOSSIL.jpg" },
    { id: 3, name: "Apple Watch & Airpods", price: 50, image: "./images/Products/Apple Watch & Airpods.jpg" },
    { id: 4, name: "APPLE WATCH", price: 20, image: "./images/Products/APPLE WATCH.jpg" },
    { id: 5, name: "Samsung Earbuds", price: 15, image: "./images/Products/Samsung Earbuds.jpg" },
    { id: 6, name: "Samsung Watch & Earbuds", price: 30, image: "./images/Products/Samsung Watch & Earbuds.jpg" },
    { id: 7, name: "Airpods 3", price: 15, image: "./images/Products/Airpods 3.jpg" },
    { id: 8, name: "Emporio Armani", price: 22, image: "./images/Products/erompori.jpg" },
    { id: 9, name: "Rolex", price: 25, image: "./images/Products/Rolex.jpg" },
    { id: 10, name: "Louis Vuitton", price: 14, image: "./images/Products/Louis Vuitton.jpg" }
];

let cart = JSON.parse(localStorage.getItem('cart')) || [];

function renderProducts() {
    const productsContainer = document.getElementById('products');
    productsContainer.innerHTML = products.map(product => `
        <div class="product">
            <img src="${product.image}" alt="${product.name}">
            <div class="product-info">
                <h3>${product.name}</h3>
                <p>$${product.price}</p>
                <button class="btn" onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        </div>
    `).join('');
}

function renderCart() {
    const cartItemsContainer = document.getElementById('cart-items');
    cartItemsContainer.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-details">
                <h4>${item.name}</h4>
                <p>$${item.price}</p>
                <div class="quantity-control">
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity - 1})">-</button>
                    <input type="number" min="1" value="${item.quantity}" onchange="updateQuantity(${item.id}, this.value)">
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
                </div>
            </div>
        </div>
    `).join('');
    updateTotal();
    updateCartCount();
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
}

function updateQuantity(productId, newQuantity) {
    newQuantity = parseInt(newQuantity);
    const item = cart.find(item => item.id === productId);
    if (item) {
        if (newQuantity > 0) {
            item.quantity = newQuantity;
        } else {
            cart = cart.filter(i => i.id !== productId);
        }
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
}

function updateTotal() {
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    document.getElementById('cart-total').textContent = total.toFixed(2);
    const checkoutBtn = document.getElementById('checkout-btn');
    checkoutBtn.disabled = cart.length === 0;
}

function updateCartCount() {
    const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cart-count').textContent = cartCount;
}

document.getElementById('checkout-btn').addEventListener('click', () => {
    window.location.href = 'checkout.html';
});

document.getElementById('clear-cart').addEventListener('click', () => {
    cart = [];
    localStorage.removeItem('cart');
    renderCart();
});

document.getElementById('floating-cart-btn').addEventListener('click', () => {
    document.getElementById('cart').classList.add('open');
});

document.getElementById('close-cart').addEventListener('click', () => {
    document.getElementById('cart').classList.remove('open');
});

renderProducts();
renderCart();
